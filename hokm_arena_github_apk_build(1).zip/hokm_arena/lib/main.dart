import 'package:flutter/material.dart';

void main() => runApp(const HokmArenaApp());

class HokmArenaApp extends StatelessWidget {
  const HokmArenaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Hokm Arena',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF10130F),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFD4AF37), brightness: Brightness.dark),
      useMaterial3: true,
    ),
    home: const GameScreen(),
  );
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});
  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  final List<String> hand = ['A♠','K♥','Q♠','10♦','9♣','8♥','7♠','6♦'];
  final List<String> played = [];
  int score = 0;
  String status = 'نوبت شماست؛ یک کارت انتخاب کنید';

  void play(String card) => setState(() {
    hand.remove(card);
    played.add(card);
    status = 'کارت $card بازی شد';
    if (played.length == 4) {
      played.clear();
      score++;
      status = 'یک دور نمایشی به امتیاز تیم شما اضافه شد';
    }
  });

  Widget player(String name) => Column(mainAxisSize: MainAxisSize.min, children: [
    const CircleAvatar(backgroundColor: Color(0xFFD4AF37), child: Icon(Icons.person, color: Colors.black)),
    const SizedBox(height: 4),
    Text(name, style: const TextStyle(fontSize: 11, color: Colors.white70)),
    Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (_) => Container(
      margin: const EdgeInsets.all(2), width: 19, height: 28,
      decoration: BoxDecoration(color: const Color(0xFF20364A), border: Border.all(color: const Color(0xFFD4AF37)), borderRadius: BorderRadius.circular(4)),
      child: const Icon(Icons.star, size: 9, color: Color(0xFFD4AF37)),
    )))
  ]);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('HOKM ARENA', style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.w900, letterSpacing: 2)), centerTitle: true),
    body: SafeArea(child: Column(children: [
      const SizedBox(height: 12),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        Column(children: [const Text('تیم شما'), Text('$score', style: const TextStyle(fontSize: 24, color: Color(0xFFD4AF37)))]),
        const Column(children: [Text('حکم'), Text('♥ دل', style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold))]),
        const Column(children: [Text('حریف'), Text('0', style: TextStyle(fontSize: 24, color: Color(0xFFD4AF37)))]),
      ]),
      const SizedBox(height: 18),
      player('بازیکن شمال'),
      const Spacer(),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        player('بازیکن غرب'),
        Container(width: 220, height: 165, decoration: BoxDecoration(color: const Color(0xFF17452F), borderRadius: BorderRadius.circular(90), border: Border.all(color: const Color(0xFFD4AF37), width: 2)),
          alignment: Alignment.center, child: played.isEmpty ? const Text('HOKM ARENA', style: TextStyle(color: Colors.white54, letterSpacing: 2)) : Wrap(children: played.map((c) => Padding(padding: const EdgeInsets.all(4), child: _CardFace(card: c))).toList())),
        player('بازیکن شرق'),
      ]),
      const Spacer(),
      Padding(padding: const EdgeInsets.all(8), child: Text(status, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFD4AF37)))),
      const Text('دست شما', style: TextStyle(color: Colors.white70)),
      SizedBox(height: 100, child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), scrollDirection: Axis.horizontal, itemCount: hand.length,
        separatorBuilder: (_, __) => const SizedBox(width: 5),
        itemBuilder: (_, i) => GestureDetector(onTap: () => play(hand[i]), child: _CardFace(card: hand[i])),
      )),
      Padding(padding: const EdgeInsets.all(12), child: OutlinedButton.icon(
        onPressed: () => setState(() { hand..clear()..addAll(['A♠','K♥','Q♠','10♦','9♣','8♥','7♠','6♦']); played.clear(); score = 0; status = 'بازی از نو شروع شد'; }),
        icon: const Icon(Icons.refresh), label: const Text('شروع دوباره'),
      )),
    ])),
  );
}

class _CardFace extends StatelessWidget {
  const _CardFace({required this.card});
  final String card;
  @override
  Widget build(BuildContext context) => Container(
    width: 54, height: 82, alignment: Alignment.center,
    decoration: BoxDecoration(color: const Color(0xFFFFF8E9), borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFFD4AF37))),
    child: Text(card, style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: card.endsWith('♥') || card.endsWith('♦') ? Colors.red : Colors.black)),
  );
}
